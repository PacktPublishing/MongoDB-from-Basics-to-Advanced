var mongoose = require('mongoose')
mongoose.Promise = require('bluebird')

mongoose.connect('mongodb://<USER>:<PASSWORD>@<DATABASE>')
	.then(() => {
		console.log('success')
	}).catch(() => {
		console.log('error')
	})
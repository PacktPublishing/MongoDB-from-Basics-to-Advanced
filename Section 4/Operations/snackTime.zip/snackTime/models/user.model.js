const UserModel = require('../schemas/user.schema')

/* Create */
UserModel.createNew = function(userObj) {
  const newUser = new UserModel({
    name: userObj.name,
    email: userObj.email,
    userName: userObj.userName
  })

  return newUser.save().then(result => {
    return result
  }).catch(error => {
    return error
  })
}

module.exports = UserModel
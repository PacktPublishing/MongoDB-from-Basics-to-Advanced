const UserModel = require('../models/user.model')

const UserController = {}

UserController.createNewUser = (req, res, next) => {
  return UserModel.createNew(req.body.userObj).then(result => {
    return res.json(result)
  }).catch(error => {
    return res.json(error)
  })
}

module.exports = UserController
const SnackModel = require('../schemas/snack.schema')

SnackModel.Insert = function() {
	const newSnack = new SnackModel({
		snack: 'Cupcake',
		store: true,
		savory: false,
		sweet: true,
		requiresPrep: true,
		prepTime: 13
	})

	return newSnack.save().then(result => {
		return result
	}).catch(error => {
		return error
	})
}

module.exports = SnackModel